Java Level Editor V0.5 by Ergo21

Introduction
This is a 3D Level Editor in Java 1.8, and was developed on Windows 7 with Eclipse. This is a tool in the spirit of Bethesda's "Creation Kit" and is used to create a game world.
It is not a model creator, and offers only simple transformations, such as scaling, rather than more advanced functions like vertex manipulation.
The game world created can be used in any game that uses JavaFX and has a parser for this format. A simple DemoGame is included. 


Installation

For consumers:
You will require Java 1.8.
Simply extract the .zip file and run "Java Level Editor".

For developers:
You will require Java 1.8, and the libraries found here: http://www.interactivemesh.org/models/jfx3dimporter.html.
Pull the Git project, attach the libraries, and run baseProgram.MainWindow.


Controls

Getting Started:
On its own the program does very little, and requires plugins to gain functionality (some of which are provided). Hence, your first step is to "Load Plugins".

3D Window:
This window displays the world as it will be played.

Left Click- Select object
CTRL + Left Click- Select Multiple Objects
Hold Right Button- Orbits around selected objects, if none are selected the camera will rotate with mouse.

SHIFT + X/Y/Z- Moves selected objects, along the appropriate axis.
CTRL + X/Y/Z- Rotates selected objects, around the appropriate axis.
ALT + X/Y/Z/A- Scales selected objects, along the appropriate axis. A will give uniform scale.

WASD- Move Camera.
L- Look at selected objects.
R- Resets window, particularly useful if controls act oddly.


Tree Window:
These windows keeps track of the world and the current level, listing their inhabitants.

Right Click- Will open context menu, if the lowest item is clicked on. This is used to put loaded models into the Current Level, Create, Delete, and Load Levels.


Loading Models:
Click on Plugins/3D Model Loader/Load New Model. Choose appropriate model, then load the model using the Tree Windows Right Click.


Creating new items:
Click on File/New/New Item in Current Level. This will open a window to create a new item, with appropriate fields.


Activator Scripting:
When creating an Activator you will need to provide a script for it to act.

First, you define when it acts. Then what it does when it acts.

Code Example:
when(pressed){
	remove(3);
	setLevel(2);
}

This code will remove the item with ID "3", then change the level to Level2. It will do this when the player presses it (E in Demo Game, when in range).

Currently "when" can have the value "pressed".

"remove()" and "setLevel()" are the only commands it can give. Do NOT pass "setLevel(Level1)", just use the end number.  


Demo Game:
"Plays" the Current Level, though Activators can change the Level.


Loading/Saving:
Under the "File" tab.

